create
    definer = bryan@`%` procedure SP_SISREHU_TM_PERSONA_INSERTAR(IN p_ID_PAIS int, IN p_ID_TIPO_DOCUMENTO int,
                                                                 IN p_ID_RELIGION int, IN p_ID_ESTADO_CIVIL int,
                                                                 IN p_ID_NIVEL_EDUCATIVO int, IN p_ID_IDIOMA int,
                                                                 IN p_ID_OCUPACION int,
                                                                 IN p_NUMERO_DOCUMENTO varchar(20),
                                                                 IN p_FECHA_VENCIMIENTO_DOCUMENTO datetime,
                                                                 IN p_APELLIDO_PATERNO varchar(128),
                                                                 IN p_APELLIDO_MATERNO varchar(128),
                                                                 IN p_NOMBRE varchar(128), IN p_FLAG_SEXO varchar(1),
                                                                 IN p_FECHA_NACIMIENTO datetime,
                                                                 IN p_TELEFONO varchar(10),
                                                                 IN p_TELEFONO_ALTERNATIVO varchar(10),
                                                                 IN p_EMAIL varchar(128),
                                                                 IN p_EMAIL_ALTERNATIVO varchar(128),
                                                                 IN p_ID_TIPO_ZONA int, IN p_NOMBRE_ZONA varchar(128),
                                                                 IN p_ID_TIPO_VIA int, IN p_NOMBRE_VIA varchar(128),
                                                                 IN p_NUMERO int, IN p_KILOMETRO decimal(18, 1),
                                                                 IN p_MANZANA varchar(8), IN p_INTERIOR varchar(8),
                                                                 IN p_LOTE varchar(8), IN p_DEPARTAMENTO varchar(8),
                                                                 IN p_OTRO_RELIGION varchar(8),
                                                                 IN p_CORREO_INSTITUCIONAL varchar(128), IN p_FOTO blob,
                                                                 IN p_FLAG_SUSPENDIDA varchar(1),
                                                                 IN p_ID_USUARIO_MODIFICA int,
                                                                 IN p_SITUACION_REGISTRO varchar(1),
                                                                 IN p_ID_USUARIO_REGISTRA int)
BEGIN
    DECLARE v_count INT;

    -- Verificar si ya existe el NUMERO_DOCUMENTO
    SELECT COUNT(*) INTO v_count FROM TM_PERSONA WHERE NUMERO_DOCUMENTO = p_NUMERO_DOCUMENTO;

    IF v_count > 0 THEN
        -- Si existe, lanzar un error o mensaje
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error: Ya existe una persona con ese número de documento.';
    ELSE
        -- Si no existe, insertar el registro
        INSERT INTO TM_PERSONA (
            ID_PAIS, ID_TIPO_DOCUMENTO, ID_RELIGION, ID_ESTADO_CIVIL, ID_NIVEL_EDUCATIVO,
            ID_IDIOMA, ID_OCUPACION, NUMERO_DOCUMENTO, FECHA_VENCIMIENTO_DOCUMENTO,
            APELLIDO_PATERNO, APELLIDO_MATERNO, NOMBRE, FLAG_SEXO, FECHA_NACIMIENTO,
            TELEFONO, TELEFONO_ALTERNATIVO, EMAIL, EMAIL_ALTERNATIVO,
            ID_TIPO_ZONA, NOMBRE_ZONA, ID_TIPO_VIA, NOMBRE_VIA, NUMERO, KILOMETRO,
            MANZANA, INTERIOR, LOTE, DEPARTAMENTO, OTRO_RELIGION, CORREO_INSTITUCIONAL,
            FOTO, FLAG_SUSPENDIDA, ID_USUARIO_MODIFICA, FECHA_MODIFICA, SITUACION_REGISTRO,
            ID_USUARIO_REGISTRA, FECHA_REGISTRA
        )
        VALUES (
            p_ID_PAIS, p_ID_TIPO_DOCUMENTO, p_ID_RELIGION, p_ID_ESTADO_CIVIL, p_ID_NIVEL_EDUCATIVO,
            p_ID_IDIOMA, p_ID_OCUPACION, p_NUMERO_DOCUMENTO, p_FECHA_VENCIMIENTO_DOCUMENTO,
            p_APELLIDO_PATERNO, p_APELLIDO_MATERNO, p_NOMBRE, p_FLAG_SEXO, p_FECHA_NACIMIENTO,
            p_TELEFONO, p_TELEFONO_ALTERNATIVO, p_EMAIL, p_EMAIL_ALTERNATIVO,
            p_ID_TIPO_ZONA, p_NOMBRE_ZONA, p_ID_TIPO_VIA, p_NOMBRE_VIA, p_NUMERO, p_KILOMETRO,
            p_MANZANA, p_INTERIOR, p_LOTE, p_DEPARTAMENTO, p_OTRO_RELIGION, p_CORREO_INSTITUCIONAL,
            p_FOTO, p_FLAG_SUSPENDIDA, p_ID_USUARIO_MODIFICA, NOW(), p_SITUACION_REGISTRO,
            p_ID_USUARIO_REGISTRA, NOW()
        );
    END IF;
END;

